<?php
require_once './../../include/functions.php';
echo getAvailQues();
?>